# uv

An extremely fast Python package and project manager, written in Rust.
