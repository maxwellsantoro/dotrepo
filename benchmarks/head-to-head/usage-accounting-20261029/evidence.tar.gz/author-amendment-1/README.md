# Usage normalization amendment 1

Preserves original author freeze227b02ef and independent BEFORE31785f26. The three retained normalization examples now reject both cost and streak qualification after normalization and aggregation. Inconsistent subtotal999 and boolean/negative unknown-call counters can no longer become complete known usage.

Five Python files changed; the other15 live bindings, including all Rust, are unchanged. Supplied metadata is checked before defaults. Invalidity remains visible through aggregation; only four bounded relevant usage scalar values/type descriptions and field reason codes are retained. Invalid spend is excluded from the known subtotal, with null total, unknown call count and false completeness. Strict gates classify it malformed and refuse qualification; no cost is inferred. Valid missing/null/zero/mixed/legacy/no-call behavior remains covered.

124 focused Python controls and31 immutable reviewer positive controls pass; all3 reviewer end-to-end false acceptances now reject. Ruff/format pass. No new provider, upstream/native, daemon or external network actions. Independent after-review and integrated gates remain pending. No further source edits are planned.
