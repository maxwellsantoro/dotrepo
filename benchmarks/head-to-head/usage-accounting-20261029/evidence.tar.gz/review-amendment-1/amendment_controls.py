"""Bounded metadata propagation controls; no provider or subprocess calls."""

import argparse
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo / "scripts"))
    import run_autonomous_index_batch as batch
    import check_autonomous_telemetry_gate as gate
    import render_unit_cost_report as renderer

    observations = []
    valid = {
        "adjudicationCalls": 1,
        "tokensUsed": 120,
        "tokensUsedKnownSubtotal": 120,
        "unknownTokenUsageCalls": 0,
        "tokenUsageComplete": True,
    }
    zero = {**valid, "tokensUsed": 0, "tokensUsedKnownSubtotal": 0}
    for field, value in [
        ("tokensUsedKnownSubtotal", 999),
        ("tokensUsedKnownSubtotal", None),
        ("tokensUsedKnownSubtotal", True),
        ("unknownTokenUsageCalls", False),
        ("unknownTokenUsageCalls", -1),
        ("unknownTokenUsageCalls", 2),
        ("unknownTokenUsageCalls", None),
        ("tokensUsed", None),
        ("tokensUsed", False),
        ("tokensUsed", "120"),
        ("tokenUsageComplete", 1),
        ("tokenUsageComplete", False),
    ]:
        raw = {**valid, field: value}
        normalized = batch.token_usage(raw)
        assert normalized["tokenUsageInvalid"] is True
        assert normalized["tokensUsed"] is None and normalized["tokenUsageComplete"] is False
        assert not gate.token_usage_well_formed(normalized) and not gate.token_usage_complete(
            normalized
        )
        again = batch.token_usage({**normalized, "adjudicationCalls": 1})
        assert again["tokenUsageInvalid"] is True
        assert again["tokensUsed"] is None and again["tokenUsageComplete"] is False
        # The contract preserves invalidity and bounded diagnostics, not exact
        # idempotence of nested type-description objects after normalization.
        aggregation = batch.aggregate_token_usage([valid, normalized, zero])
        assert aggregation["tokenUsageInvalid"] is True and aggregation["tokensUsed"] is None
        assert (
            aggregation["tokensUsedKnownSubtotal"] == 120
            and aggregation["unknownTokenUsageCalls"] is None
        )
        assert not gate.token_usage_complete(aggregation)
        rendered = renderer.summarize_category("changed", [normalized])
        assert rendered["tokensUsed"]["sampled"] == 0 and rendered["tokensUsed"]["unknown"] == 1
        observations.append(
            {
                "raw": raw,
                "normalized": normalized,
                "aggregate": aggregation,
                "renderer": rendered["tokensUsed"],
            }
        )
    for raw in [
        valid,
        zero,
        {"adjudicationCalls": 0, "tokensUsed": 0},
        {"adjudicationCalls": 1, "tokensUsed": 120},
    ]:
        normalized = batch.token_usage(raw)
        assert normalized.get("tokenUsageInvalid") is not True
        assert normalized["tokenUsageComplete"] is (
            raw.get("tokenUsageComplete") is True or raw["adjudicationCalls"] == 0
        )
    with args.output.open("x") as handle:
        json.dump(
            {
                "malformedVariantsPassed": len(observations),
                "validLegacyVariantsPassed": 4,
                "observations": observations,
                "providerCalls": 0,
            },
            handle,
            indent=2,
            sort_keys=True,
        )
        handle.write("\n")
    print("12 malformed and4 valid/legacy variants passed")


if __name__ == "__main__":
    main()
