"""Owned retained-data/fake-provider usage review controls. No real provider calls."""

from __future__ import annotations
import argparse
import importlib.util
import io
import json
from pathlib import Path
import sys
import urllib.error
from unittest.mock import patch


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(value)
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo / "scripts"))
    import openrouter_request_policy as policy
    import adjudication_openrouter_sidecar as sidecar
    import run_autonomous_index_batch as batch
    import check_autonomous_telemetry_gate as gate
    import check_refresh_streak as streak
    import render_unit_cost_report as renderer

    gt = module(
        "review_gate_fixtures", args.repo / "scripts/tests/test_autonomous_telemetry_gate.py"
    )
    st = module("review_streak_fixtures", args.repo / "scripts/tests/test_refresh_streak.py")
    results = []

    def record(name, actual, passed):
        results.append({"name": name, "actual": actual, "passed": bool(passed)})
        assert passed, name

    answer = {
        "field": "repo.build",
        "value": None,
        "source": None,
        "confidence": "low",
        "reason": "owned",
    }
    request = {"field": "repo.build", "candidates": [], "model": policy.DEFAULT_PRIMARY_MODEL}
    for native, expected in [
        ({}, None),
        ({"total_tokens": None}, None),
        ({"total_tokens": 0}, 0),
        ({"total_tokens": 120}, 120),
        ({"total_tokens": False}, None),
        ({"total_tokens": -1}, None),
        ({"total_tokens": "0"}, None),
    ]:
        for invalid in [False, True]:
            payload = {
                "id": "owned",
                "model": policy.DEFAULT_PRIMARY_MODEL,
                "choices": [
                    {
                        "message": {"content": "invalid" if invalid else json.dumps(answer)},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {**native, "cost": 0.75},
            }
            with patch.object(
                sidecar.urllib.request,
                "urlopen",
                return_value=io.BytesIO(json.dumps(payload).encode()),
            ):
                if invalid:
                    try:
                        sidecar.call_openrouter(
                            api_key="owned-not-secret",
                            model=policy.DEFAULT_PRIMARY_MODEL,
                            prompt="owned",
                        )
                        raise AssertionError("invalid answer accepted")
                    except policy.CompletionError as error:
                        usage = error.usage
                        record(
                            "invalid-answer-native-" + repr(native),
                            usage,
                            usage["tokensUsed"] == expected
                            and usage["tokenUsageComplete"] is (expected is not None)
                            and usage["cost"] == 0.75,
                        )
                else:
                    parsed, tokens = sidecar.call_openrouter(
                        api_key="owned-not-secret",
                        model=policy.DEFAULT_PRIMARY_MODEL,
                        prompt="owned",
                    )
                    response = sidecar.normalize_response(request, parsed, tokens)
                    record(
                        "sidecar-native-" + repr(native),
                        response,
                        response["tokensUsed"] == expected
                        and response["tokenUsageComplete"] is (expected is not None),
                    )

    for known in [None, 0, 120]:
        native = {} if known is None else {"total_tokens": known}
        failure = urllib.error.HTTPError(
            "https://unused.invalid",
            429,
            "owned",
            {},
            io.BytesIO(json.dumps({"usage": native}).encode()),
        )
        with patch.object(sidecar.urllib.request, "urlopen", side_effect=failure):
            handler = object.__new__(sidecar.make_handler("owned-not-secret"))
            raw = json.dumps(request).encode()
            handler.path = "/adjudicate"
            handler.headers = {"Content-Length": str(len(raw))}
            handler.rfile, handler.wfile = io.BytesIO(raw), io.BytesIO()
            statuses = []
            handler.send_response = statuses.append
            handler.send_header = lambda *unused: None
            handler.end_headers = lambda: None
            handler.do_POST()
            result = json.loads(handler.wfile.getvalue())
            record(
                "http-error-native-" + str(known),
                result,
                statuses == [502]
                and result["tokensUsed"] == known
                and result["tokenUsageComplete"] is (known is not None),
            )
    with patch.object(
        sidecar, "call_openrouter", side_effect=RuntimeError("owned transport failure")
    ):
        handler = object.__new__(sidecar.make_handler("owned-not-secret"))
        raw = json.dumps(request).encode()
        handler.path, handler.headers = "/adjudicate", {"Content-Length": str(len(raw))}
        handler.rfile, handler.wfile = io.BytesIO(raw), io.BytesIO()
        handler.send_response = lambda *unused: None
        handler.send_header = lambda *unused: None
        handler.end_headers = lambda: None
        handler.do_POST()
        response = json.loads(handler.wfile.getvalue())
        record(
            "generic-error-unknown",
            response,
            response["tokensUsed"] is None and response["tokenUsageComplete"] is False,
        )

    rows = [
        {"adjudicationCalls": 1, "tokensUsed": 120, "tokenUsageComplete": True},
        {
            "adjudicationCalls": 1,
            "tokensUsed": None,
            "tokensUsedKnownSubtotal": 0,
            "unknownTokenUsageCalls": 1,
            "tokenUsageComplete": False,
        },
        {"adjudicationCalls": 1, "tokensUsed": 0, "tokenUsageComplete": True},
    ]
    for name, aggregate in [
        ("mixed-cost", batch.aggregate_costs(rows)),
        ("mixed-summary", batch.aggregate_runs(rows)["totals"]),
    ]:
        record(
            name,
            aggregate,
            aggregate["tokensUsed"] is None
            and aggregate["tokensUsedKnownSubtotal"] == 120
            and aggregate["unknownTokenUsageCalls"] == 1
            and aggregate["tokenUsageComplete"] is False,
        )
    usages = [
        {
            "tokensUsed": None,
            "tokensUsedKnownSubtotal": 120,
            "unknownTokenUsageCalls": 1,
            "tokenUsageComplete": False,
        },
        {"tokensUsed": 0},
        {"tokensUsed": 120},
    ]
    for usage in usages:
        summary = gt.usage_summary(usage)
        result = gate.evaluate(summary, gt.args())
        record(
            "strict-cost-refuses-" + repr(usage),
            {"passed": result["passed"], "inputs": result["inputs"]},
            not result["passed"] and result["inputs"]["tokensUsed"] is None,
        )
        entries = st.entries()
        entries[0]["receipt"]["budget"].update(
            adjudicationCallBudget=1, adjudicationCalls=1, **usage
        )
        result = streak.assess(entries, now=st.NOW)
        record(
            "streak-refuses-" + repr(usage),
            {"passed": result["passed"], "qualifiedDays": result["qualifiedDays"]},
            not result["passed"] and result["qualifiedDays"] == 0,
        )
    for calls, usage in [
        (0, {"tokensUsed": 0}),
        (
            1,
            {
                "tokensUsed": 0,
                "tokensUsedKnownSubtotal": 0,
                "unknownTokenUsageCalls": 0,
                "tokenUsageComplete": True,
            },
        ),
    ]:
        summary = gt.usage_summary(usage)
        summary["totals"]["adjudicationCalls"] = calls
        result = gate.evaluate(summary, gt.args())
        record("explicit-zero-gate-" + str(calls), result["passed"], result["passed"])
        entries = st.entries()
        entries[0]["receipt"]["budget"].update(
            adjudicationCallBudget=1, adjudicationCalls=calls, **usage
        )
        result = streak.assess(entries, now=st.NOW)
        record("explicit-zero-streak-" + str(calls), result["passed"], result["passed"])
    sample = renderer.summarize_category(
        "changed", [*rows, {"adjudicationCalls": 1, "tokensUsed": 80}]
    )
    record(
        "renderer-excludes-unknown-and-legacy-called",
        sample["tokensUsed"],
        sample["tokensUsed"]["sampled"] == 2 and sample["tokensUsed"]["unknown"] == 2,
    )
    contradictory = []
    for row in [
        {
            "adjudicationCalls": 1,
            "tokensUsed": 120,
            "tokensUsedKnownSubtotal": 999,
            "unknownTokenUsageCalls": 0,
            "tokenUsageComplete": True,
        },
        {
            "adjudicationCalls": 1,
            "tokensUsed": 0,
            "tokensUsedKnownSubtotal": 0,
            "unknownTokenUsageCalls": False,
            "tokenUsageComplete": True,
        },
        {
            "adjudicationCalls": 1,
            "tokensUsed": 0,
            "tokensUsedKnownSubtotal": 0,
            "unknownTokenUsageCalls": -1,
            "tokenUsageComplete": True,
        },
    ]:
        normalized = batch.token_usage(row)
        summary = gt.usage_summary(normalized)
        cost = gate.evaluate(summary, gt.args())
        entries = st.entries()
        entries[0]["receipt"]["budget"].update(
            adjudicationCallBudget=1, adjudicationCalls=1, **normalized
        )
        outcome = streak.assess(entries, now=st.NOW)
        contradictory.append(
            {
                "raw": row,
                "rawWellFormed": gate.token_usage_well_formed(row),
                "normalized": normalized,
                "normalizedCostGatePassed": cost["passed"],
                "normalizedStreakPassed": outcome["passed"],
            }
        )
    with args.output.open("x") as handle:
        json.dump(
            {
                "validControls": results,
                "contradictoryNormalization": contradictory,
                "providerCalls": 0,
                "externalHTTP": False,
            },
            handle,
            sort_keys=True,
            indent=2,
        )
        handle.write("\n")
    print(
        json.dumps(
            {
                "validControlsPassed": len(results),
                "contradictoryNormalizationCases": len(contradictory),
                "costGateFalsePasses": sum(x["normalizedCostGatePassed"] for x in contradictory),
                "streakFalsePasses": sum(x["normalizedStreakPassed"] for x in contradictory),
            }
        )
    )


if __name__ == "__main__":
    main()
